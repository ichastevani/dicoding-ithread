import React from 'react';
import PropTypes from 'prop-types';
import PapanPeringkatItem, {rankingDataSchema} from "./PapanPeringkatItem.jsx";

function PapanPeringkatList({ leaderboards }) {
    return (
        <ul className="list-group list-group-flush">
            {
                leaderboards.map((leaderboard, key) => (
                    <PapanPeringkatItem key={key} leaderboard={leaderboard}/>
                ))
            }
        </ul>
    );
}

PapanPeringkatList.propTypes = {
    leaderboards: PropTypes.arrayOf(PropTypes.shape(rankingDataSchema)).isRequired,
};

export default PapanPeringkatList;
