import LoadingBar from 'react-redux-loading-bar';
import React from 'react';

function Loading() {
  return (
    <div className="loading">
      <LoadingBar />
    </div>
  );
}

export default Loading;
